
# Student Stress Analyzer

A simple Streamlit app that predicts student stress level (Low, Medium, High) from text input using a logistic regression model.

## How to Run

```bash
pip install -r requirements.txt
streamlit run app.py
```
