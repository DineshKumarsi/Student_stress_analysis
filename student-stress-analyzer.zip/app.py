
import streamlit as st
import joblib

model = joblib.load("stress_model.pkl")

st.set_page_config(page_title="Student Stress Analyzer")
st.title("Student Stress Analyzer 🧠")
st.markdown("Enter how you're feeling. We'll detect your stress level.")

text = st.text_area("Describe your day or feelings:")

if st.button("Analyze"):
    result = model.predict([text])[0]
    st.success(f"Predicted Stress Level: **{result}**")

    if result.lower() == 'high':
        st.warning("Try deep breathing or talk to a friend.")
    elif result.lower() == 'medium':
        st.info("Take a short break and relax.")
    else:
        st.success("You're doing great. Keep it up!")
